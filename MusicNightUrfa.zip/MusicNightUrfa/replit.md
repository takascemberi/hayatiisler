# Replit.md

## Overview

This is a Turkish cultural music performer website built with a modern full-stack architecture. The application showcases a traditional Turkish musician named "Hayati İşler" who specializes in Urfa sıra geceleri (traditional Turkish musical performances). The website is built as a single-page application with a beautiful, culturally-themed design featuring animations and responsive layout.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom Turkish cultural color theme
- **Animations**: Framer Motion for smooth transitions and effects
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: Neon PostgreSQL (serverless)
- **Session Storage**: connect-pg-simple for PostgreSQL session storage
- **Development**: Hot module replacement via Vite integration

### Design System
- **Component Library**: Custom implementation using Radix UI primitives
- **Theme**: Turkish cultural colors (red, gold, brown, cream)
- **Typography**: Playfair Display for headings, Inter for body text
- **Icons**: Font Awesome 6.0
- **Responsive**: Mobile-first design approach

## Key Components

### Frontend Components
1. **Navigation**: Sticky header with smooth scroll navigation
2. **Hero Section**: Full-screen landing with background image and animations
3. **Services Section**: Grid layout showcasing different service offerings
4. **About Section**: Statistics display with experience highlights
5. **Gallery Section**: Image gallery with modal view functionality
6. **Contact Section**: Contact form with validation and toast notifications
7. **Footer**: Site information and service links

### Backend Structure
1. **Routes**: Express route handlers in `/server/routes.ts`
2. **Storage**: Abstract storage interface with in-memory implementation
3. **Database Schema**: User model defined with Drizzle ORM
4. **Middleware**: Request logging and error handling

### Shared Resources
1. **Schema**: Shared database schema definitions
2. **Types**: TypeScript type definitions for API contracts

## Data Flow

### Client-Side Data Flow
1. **Page Load**: React app initializes with Wouter routing
2. **Component Rendering**: Framer Motion animations trigger on viewport intersection
3. **User Interactions**: Form submissions handled with validation and toast feedback
4. **Navigation**: Smooth scrolling between page sections

### Server-Side Data Flow
1. **Request Processing**: Express middleware logs requests and handles errors
2. **Data Access**: Storage interface abstracts database operations
3. **Session Management**: PostgreSQL-backed session storage
4. **Static Assets**: Vite serves frontend assets in development

### Database Schema
- **Users Table**: Basic user authentication structure with username/password
- **Migration System**: Drizzle Kit handles schema migrations

## External Dependencies

### Frontend Dependencies
- **UI Components**: Extensive Radix UI component collection
- **Styling**: Tailwind CSS with custom configuration
- **Animation**: Framer Motion for advanced animations
- **Date Handling**: date-fns for date utilities
- **Form Handling**: React Hook Form with Zod validation
- **HTTP Client**: Fetch API wrapped in TanStack Query

### Backend Dependencies
- **Database**: Neon serverless PostgreSQL
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Storage**: connect-pg-simple for persistent sessions
- **Development Tools**: tsx for TypeScript execution, esbuild for production builds

### Build Tools
- **Bundler**: Vite with React plugin
- **TypeScript**: Full TypeScript configuration with path mapping
- **Linting**: ESLint configuration (implied by project structure)
- **Development**: Replit-specific development plugins

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` starts both frontend and backend
- **Hot Reload**: Vite provides instant feedback for frontend changes
- **TypeScript Checking**: `npm run check` validates TypeScript compilation

### Production Build
- **Frontend Build**: Vite creates optimized static assets
- **Backend Build**: esbuild bundles server code as ESM modules
- **Database Migration**: `npm run db:push` applies schema changes
- **Start Command**: `npm start` runs production server

### Environment Configuration
- **Database**: Requires `DATABASE_URL` environment variable
- **Session Storage**: PostgreSQL connection for session persistence
- **Static Assets**: Frontend assets served from `/dist/public`

## Recent Changes

✓ Enhanced hero section animations with 3D entrance effects and positioned titles higher
✓ Added PostgreSQL database with Drizzle ORM integration
✓ Created comprehensive database schema for contact submissions, bookings, and gallery images
✓ Implemented DatabaseStorage class replacing MemStorage for real data persistence
✓ Added API endpoints for contact forms, bookings, and gallery management
✓ Connected contact form to database with proper validation and error handling
✓ Successfully deployed database schema with `npm run db:push`
✓ Updated contact information to use correct phone number (+90 537 383 93 45) and email (hayatiisler35@gmail.com)
✓ Removed all address references - now displays "Tüm Türkiye ve dünyaya hizmet veriyoruz"
✓ Enhanced title animations with stunning gradient effects and multi-layered glows
✓ Added authentic performance photos from user's professional portfolio to gallery
✓ Implemented WhatsApp contact button with correct phone number

## Changelog

- July 04, 2025: Initial website setup with Turkish cultural design
- July 04, 2025: Enhanced animations and added PostgreSQL database integration

## User Preferences

Preferred communication style: Simple, everyday language.