import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  eventType: text("event_type"),
  message: text("message"),
  submittedAt: timestamp("submitted_at").defaultNow(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  clientName: text("client_name").notNull(),
  clientPhone: text("client_phone").notNull(),
  clientEmail: text("client_email").notNull(),
  eventType: text("event_type").notNull(),
  eventDate: timestamp("event_date").notNull(),
  eventLocation: text("event_location").notNull(),
  eventDetails: text("event_details"),
  status: text("status").notNull().default("pending"), // pending, confirmed, completed, cancelled
  createdAt: timestamp("created_at").defaultNow(),
});

export const galleryImages = pgTable("gallery_images", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  altText: text("alt_text").notNull(),
  eventType: text("event_type"),
  isVisible: boolean("is_visible").default(true),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

// Relations
export const contactSubmissionsRelations = relations(contactSubmissions, ({ one }) => ({
  booking: one(bookings, {
    fields: [contactSubmissions.email],
    references: [bookings.clientEmail],
  }),
}));

export const bookingsRelations = relations(bookings, ({ many }) => ({
  contactSubmissions: many(contactSubmissions),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertContactSubmissionSchema = createInsertSchema(contactSubmissions).pick({
  name: true,
  phone: true,
  email: true,
  eventType: true,
  message: true,
});

export const insertBookingSchema = createInsertSchema(bookings).pick({
  clientName: true,
  clientPhone: true,
  clientEmail: true,
  eventType: true,
  eventDate: true,
  eventLocation: true,
  eventDetails: true,
  status: true,
});

export const insertGalleryImageSchema = createInsertSchema(galleryImages).pick({
  title: true,
  description: true,
  imageUrl: true,
  altText: true,
  eventType: true,
  isVisible: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertContactSubmission = z.infer<typeof insertContactSubmissionSchema>;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;

export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

export type InsertGalleryImage = z.infer<typeof insertGalleryImageSchema>;
export type GalleryImage = typeof galleryImages.$inferSelect;
