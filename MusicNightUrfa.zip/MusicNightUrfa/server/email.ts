import { MailService } from '@sendgrid/mail';

// SendGrid API anahtarını doğrudan burada tanımlayın veya environment'dan alın
const SENDGRID_API_KEY: string = process.env.SENDGRID_API_KEY || "SG.G64G844MRJ7YANKN9UK22S9Q";

const mailService = new MailService();
mailService.setApiKey(SENDGRID_API_KEY);

interface ContactEmailParams {
  name: string;
  phone: string;
  email: string;
  eventType?: string;
  message?: string;
}

export async function sendContactNotification(params: ContactEmailParams): Promise<boolean> {
  try {
    const emailContent = `
Yeni İletişim Formu Mesajı
========================

İsim: ${params.name}
Telefon: ${params.phone}
E-posta: ${params.email}
Etkinlik Türü: ${params.eventType || 'Belirtilmemiş'}

Mesaj:
${params.message || 'Mesaj yazılmamış'}

========================
Bu mesaj Hayati İşler web sitesi iletişim formundan gönderilmiştir.
`;

    const htmlContent = `
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
  <h2 style="color: #DC143C; text-align: center;">Yeni İletişim Formu Mesajı</h2>
  
  <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <h3 style="color: #DAA520; margin-top: 0;">İletişim Bilgileri</h3>
    <p><strong>İsim:</strong> ${params.name}</p>
    <p><strong>Telefon:</strong> ${params.phone}</p>
    <p><strong>E-posta:</strong> ${params.email}</p>
    <p><strong>Etkinlik Türü:</strong> ${params.eventType || 'Belirtilmemiş'}</p>
  </div>
  
  <div style="background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <h3 style="color: #DAA520; margin-top: 0;">Mesaj</h3>
    <p style="white-space: pre-line;">${params.message || 'Mesaj yazılmamış'}</p>
  </div>
  
  <div style="text-align: center; margin-top: 30px; padding: 10px; background-color: #fff8dc; border-radius: 5px;">
    <p style="color: #8B4513; font-size: 12px; margin: 0;">
      Bu mesaj Hayati İşler web sitesi iletişim formundan gönderilmiştir.
    </p>
  </div>
</div>
`;

    await mailService.send({
      to: 'hayatiisler35@gmail.com',
      from: 'hayatiisler35@gmail.com', // Kendi email adresinizi kullanın
      subject: `Yeni İletişim Mesajı - ${params.name}`,
      text: emailContent,
      html: htmlContent,
    });

    return true;
  } catch (error) {
    console.error('Email gönderim hatası:', error);
    return false;
  }
}