import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema, insertBookingSchema, insertGalleryImageSchema } from "@shared/schema";
import { sendContactNotification } from "./email";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact submission endpoint
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const contactSubmission = await storage.createContactSubmission(validatedData);
      console.log(`Contact submission created: ${contactSubmission.name} - ${contactSubmission.email}`);
      
      // Send email notification
      const emailSent = await sendContactNotification({
        name: contactSubmission.name,
        phone: contactSubmission.phone,
        email: contactSubmission.email,
        eventType: contactSubmission.eventType || undefined,
        message: contactSubmission.message || undefined
      });
      
      if (emailSent) {
        console.log(`Email notification sent for: ${contactSubmission.name}`);
      } else {
        console.error(`Failed to send email notification for: ${contactSubmission.name}`);
      }
      
      res.json({ success: true, data: contactSubmission });
    } catch (error) {
      console.error(`Contact submission error: ${error}`);
      res.status(400).json({ success: false, error: "Invalid contact data" });
    }
  });

  // Get all contact submissions (admin endpoint)
  app.get("/api/contact", async (req: Request, res: Response) => {
    try {
      const submissions = await storage.getContactSubmissions();
      res.json({ success: true, data: submissions });
    } catch (error) {
      console.error(`Get contact submissions error: ${error}`);
      res.status(500).json({ success: false, error: "Failed to fetch submissions" });
    }
  });

  // Create booking endpoint
  app.post("/api/bookings", async (req: Request, res: Response) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      console.log(`Booking created: ${booking.clientName} - ${booking.eventType}`);
      res.json({ success: true, data: booking });
    } catch (error) {
      console.error(`Booking creation error: ${error}`);
      res.status(400).json({ success: false, error: "Invalid booking data" });
    }
  });

  // Get all bookings (admin endpoint)
  app.get("/api/bookings", async (req: Request, res: Response) => {
    try {
      const bookings = await storage.getBookings();
      res.json({ success: true, data: bookings });
    } catch (error) {
      console.error(`Get bookings error: ${error}`);
      res.status(500).json({ success: false, error: "Failed to fetch bookings" });
    }
  });

  // Update booking status
  app.patch("/api/bookings/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const updatedBooking = await storage.updateBookingStatus(id, status);
      
      if (!updatedBooking) {
        return res.status(404).json({ success: false, error: "Booking not found" });
      }
      
      console.log(`Booking status updated: ${id} - ${status}`);
      res.json({ success: true, data: updatedBooking });
    } catch (error) {
      console.error(`Update booking status error: ${error}`);
      res.status(400).json({ success: false, error: "Failed to update booking status" });
    }
  });

  // Create gallery image endpoint
  app.post("/api/gallery", async (req: Request, res: Response) => {
    try {
      const validatedData = insertGalleryImageSchema.parse(req.body);
      const galleryImage = await storage.createGalleryImage(validatedData);
      console.log(`Gallery image created: ${galleryImage.title}`);
      res.json({ success: true, data: galleryImage });
    } catch (error) {
      console.error(`Gallery image creation error: ${error}`);
      res.status(400).json({ success: false, error: "Invalid gallery image data" });
    }
  });

  // Get all visible gallery images
  app.get("/api/gallery", async (req: Request, res: Response) => {
    try {
      const images = await storage.getGalleryImages();
      res.json({ success: true, data: images });
    } catch (error) {
      console.error(`Get gallery images error: ${error}`);
      res.status(500).json({ success: false, error: "Failed to fetch gallery images" });
    }
  });

  // Update gallery image visibility
  app.patch("/api/gallery/:id/visibility", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { isVisible } = req.body;
      const updatedImage = await storage.updateGalleryImageVisibility(id, isVisible);
      
      if (!updatedImage) {
        return res.status(404).json({ success: false, error: "Gallery image not found" });
      }
      
      console.log(`Gallery image visibility updated: ${id} - ${isVisible}`);
      res.json({ success: true, data: updatedImage });
    } catch (error) {
      console.error(`Update gallery image visibility error: ${error}`);
      res.status(400).json({ success: false, error: "Failed to update image visibility" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
