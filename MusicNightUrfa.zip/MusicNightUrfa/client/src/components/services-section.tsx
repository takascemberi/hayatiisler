import { motion } from "framer-motion";

const services = [
  {
    icon: "fas fa-heart",
    title: "Düğün Organizasyonları",
    description: "Hayatınızın en özel gününde geleneksel Türk müziği ile unutulmaz anlar yaşatıyoruz."
  },
  {
    icon: "fas fa-music",
    title: "Konser & Sahne",
    description: "Profesyonel sahne performansları ve konser organizasyonları ile müzik severlerin kalbine dokunuyoruz."
  },
  {
    icon: "fas fa-users",
    title: "Sıra Geceleri",
    description: "Geleneksel Urfa sıra geceleri ile kültürümüzün en güzel yanlarını yaşatıyoruz."
  },
  {
    icon: "fas fa-globe",
    title: "Yurt İçi Organizasyon",
    description: "Türkiye'nin her yerinde kaliteli müzik deneyimi sunmak için hizmetinizdeyiz."
  },
  {
    icon: "fas fa-plane",
    title: "Yurt Dışı Organizasyon",
    description: "Uluslararası etkinliklerde Türk kültürünü en güzel şekilde temsil ediyoruz."
  },
  {
    icon: "fas fa-star",
    title: "Özel Etkinlikler",
    description: "Doğum günü, nişan, kına gecesi gibi özel günlerinizi unutulmaz kılıyoruz."
  }
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-gradient-to-b from-cream to-white turkish-pattern">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16 mt-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="font-playfair font-bold text-4xl md:text-5xl text-turkish-red mb-4">
            Hizmetlerimiz
          </h2>
          <p className="text-lg text-warm-brown max-w-2xl mx-auto">
            Düğünden konsere, sıra gecelerinden uluslararası organizasyonlara kadar 
            her türlü etkinliğinizde sizinle birlikte oluyoruz.
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-turkish-red/10 to-turkish-gold/10 p-8 rounded-xl border border-turkish-gold/20 hover:shadow-lg transition-all duration-300"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, boxShadow: "0 20px 40px rgba(139, 0, 0, 0.2)" }}
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-turkish-red rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className={`${service.icon} text-gold-light text-2xl`}></i>
                </div>
                <h3 className="font-playfair font-semibold text-2xl text-turkish-red mb-4">
                  {service.title}
                </h3>
                <p className="text-warm-brown leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
