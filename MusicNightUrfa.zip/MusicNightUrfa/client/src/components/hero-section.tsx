import { motion } from "framer-motion";
import musicianImagePath from "@assets/IMG-20250704-WA0004_1751589244411.jpg";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToGallery = () => {
    const element = document.getElementById("gallery");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${musicianImagePath})`,
        }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-45 from-turkish-red/80 via-warm-brown/80 to-turkish-red/80" />
      
      <div className="relative z-10 text-center px-6 max-w-6xl mx-auto -mt-32">
        {/* Animated Main Title */}
        <motion.h1
          className="font-playfair font-bold text-4xl md:text-6xl lg:text-7xl text-gold-light mb-6"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        >
          <motion.span
            className="block text-gold-light font-bold"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
            whileHover={{ scale: 1.05 }}
            style={{
              textShadow: "3px 3px 6px rgba(0,0,0,0.7), 0 0 20px rgba(218, 165, 32, 0.5)"
            }}
          >
            HAYATİ İŞLER
          </motion.span>
          <motion.span
            className="block text-3xl md:text-5xl lg:text-6xl mt-2 text-turkish-red font-bold"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
            whileHover={{ scale: 1.05 }}
            style={{
              textShadow: "3px 3px 6px rgba(0,0,0,0.7), 0 0 20px rgba(220, 20, 60, 0.5)"
            }}
          >
            URFA SIRA GECESİ
          </motion.span>
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-8"
        >
          {/* Musical Note Icon */}
          <motion.div
            className="mb-8"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            <motion.div
              className="w-20 h-20 bg-gold-light/20 rounded-full flex items-center justify-center mx-auto backdrop-blur-sm border-2 border-gold-light/50"
              animate={{ 
                rotate: [0, 10, -10, 0],
                scale: [1, 1.1, 1] 
              }}
              transition={{ 
                rotate: { duration: 4, repeat: Infinity },
                scale: { duration: 2, repeat: Infinity }
              }}
            >
              <i className="fas fa-music text-gold-light text-3xl"></i>
            </motion.div>
          </motion.div>
          

        </motion.div>
        
        <motion.div
          className="flex flex-col md:flex-row gap-4 justify-center items-center mt-8 pt-40"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1 }}
        >
          <motion.button
            onClick={scrollToContact}
            className="bg-turkish-gold hover:bg-gold-light text-turkish-red font-semibold px-8 py-4 rounded-lg transition-all duration-300 shadow-lg"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <i className="fas fa-calendar-alt mr-2"></i>
            Rezervasyon Yap
          </motion.button>
          
          {/* Text below button */}
          <motion.p 
            className="text-xl md:text-2xl text-cream mt-8 font-light text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.2 }}
          >
            <motion.span 
              className="block text-gold-light font-semibold"
              animate={{ 
                scale: [1, 1.02, 1],
                textShadow: [
                  "0 0 15px rgba(218, 165, 32, 0.6)",
                  "0 0 25px rgba(218, 165, 32, 0.9)",
                  "0 0 15px rgba(218, 165, 32, 0.6)"
                ]
              }}
              transition={{ duration: 2.5, repeat: Infinity }}
            >
              20 Yıl Tecrübe ile
            </motion.span>
            <motion.span 
              className="block text-cream font-medium"
              animate={{ opacity: [0.8, 1, 0.8] }}
              transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
            >
              Geleneksel Türk Müziği ve Sıra Geceleri
            </motion.span>
          </motion.p>
        </motion.div>
        
        {/* WhatsApp Button - Fixed Position */}
        <motion.a
          href="https://wa.me/905373839345"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 0.8, delay: 1.5 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <motion.i
            className="fab fa-whatsapp text-2xl"
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity, delay: 3 }}
          />
        </motion.a>
      </div>
      
      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <i className="fas fa-chevron-down text-gold-light text-2xl"></i>
      </motion.div>
    </section>
  );
}
