import { motion } from "framer-motion";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    eventType: "",
    message: ""
  });
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.phone || !formData.email) {
      toast({
        title: "Eksik Bilgi",
        description: "Lütfen tüm zorunlu alanları doldurun.",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Mesajınız Alındı!",
          description: "En kısa sürede size dönüş yapacağız.",
        });

        // Reset form
        setFormData({
          name: "",
          phone: "",
          email: "",
          eventType: "",
          message: ""
        });
      } else {
        throw new Error(result.error || 'Mesaj gönderilemedi');
      }
    } catch (error) {
      console.error('Contact form error:', error);
      toast({
        title: "Hata",
        description: "Mesaj gönderilirken bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive"
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const contactInfo = [
    {
      icon: "fas fa-phone",
      title: "Telefon",
      details: ["+90 537 383 93 45"]
    },
    {
      icon: "fas fa-envelope",
      title: "E-posta",
      details: ["hayatiisler35@gmail.com"]
    },
    {
      icon: "fas fa-globe",
      title: "Hizmet Alanı",
      details: ["Tüm Türkiye ve dünyaya hizmet veriyoruz"]
    }
  ];

  const socialLinks = [
    { icon: "fab fa-instagram", href: "#" },
    { icon: "fab fa-facebook", href: "#" },
    { icon: "fab fa-youtube", href: "#" },
    { icon: "fab fa-whatsapp", href: "#" }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-turkish-red to-warm-brown">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="font-playfair font-bold text-4xl md:text-5xl text-gold-light mb-4">
            İletişim
          </h2>
          <p className="text-lg text-cream max-w-2xl mx-auto">
            Etkinliğinizi planlamak ve rezervasyon yapmak için bizimle iletişime geçin
          </p>
        </motion.div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            {contactInfo.map((info, index) => (
              <motion.div
                key={index}
                className="flex items-start space-x-4 p-6 rounded-lg contact-card-gradient shadow-xl"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="w-12 h-12 bg-gold-light rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
                  <i className={`${info.icon} text-turkish-red text-xl`}></i>
                </div>
                <div className="text-cream">
                  <h3 className="font-semibold text-xl mb-2 text-white">{info.title}</h3>
                  {info.details.map((detail, idx) => (
                    <p key={idx} className={idx === 1 ? "text-sm text-cream/90 font-medium" : "text-cream font-medium"}>
                      {detail}
                    </p>
                  ))}
                </div>
              </motion.div>
            ))}
            
            <motion.div
              className="flex space-x-4 pt-4"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
            >
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  className="w-12 h-12 bg-gold-light rounded-full flex items-center justify-center hover:bg-white transition-colors duration-300"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <i className={`${social.icon} text-turkish-red text-xl`}></i>
                </motion.a>
              ))}
            </motion.div>
          </motion.div>
          
          <motion.div
            className="bg-white/10 backdrop-blur-sm rounded-xl p-8"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="font-playfair font-semibold text-2xl text-gold-light mb-6">
              Hızlı İletişim
            </h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <Input
                type="text"
                placeholder="Adınız Soyadınız"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                className="bg-white/90 border-gold-light/30 text-black placeholder-gray-600 focus:border-gold-light focus:bg-white"
                required
              />
              <Input
                type="tel"
                placeholder="Telefon Numaranız"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                className="bg-white/90 border-gold-light/30 text-black placeholder-gray-600 focus:border-gold-light focus:bg-white"
                required
              />
              <Input
                type="email"
                placeholder="E-posta Adresiniz"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                className="bg-white/90 border-gold-light/30 text-black placeholder-gray-600 focus:border-gold-light focus:bg-white"
                required
              />
              <Select value={formData.eventType} onValueChange={(value) => handleInputChange("eventType", value)}>
                <SelectTrigger className="bg-white/90 border-gold-light/30 text-black focus:border-gold-light focus:bg-white">
                  <SelectValue placeholder="Etkinlik Türü Seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="wedding">Düğün</SelectItem>
                  <SelectItem value="concert">Konser</SelectItem>
                  <SelectItem value="sira">Sıra Gecesi</SelectItem>
                  <SelectItem value="special">Özel Etkinlik</SelectItem>
                </SelectContent>
              </Select>
              <Textarea
                rows={4}
                placeholder="Mesajınız"
                value={formData.message}
                onChange={(e) => handleInputChange("message", e.target.value)}
                className="bg-white/90 border-gold-light/30 text-black placeholder-gray-600 focus:border-gold-light focus:bg-white resize-none"
              />
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  type="submit"
                  className="w-full bg-gold-light hover:bg-white text-turkish-red font-semibold py-3 px-6"
                >
                  <i className="fas fa-paper-plane mr-2"></i>
                  Mesaj Gönder
                </Button>
              </motion.div>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
