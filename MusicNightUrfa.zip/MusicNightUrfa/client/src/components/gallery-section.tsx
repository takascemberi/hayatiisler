import { motion } from "framer-motion";
import { useState } from "react";

import promoImagePath from "@assets/IMG-20250704-WA0002_1751590716689.jpg";
import tvShowImagePath from "@assets/IMG-20250704-WA0016_1751590716690.jpg";
import stagePerformancePath from "@assets/IMG-20250704-WA0021_1751590716690.jpg";
import traditionFestivalPath from "@assets/IMG-20250704-WA0022_1751590716691.jpg";
import showPerformancePath from "@assets/IMG-20250704-WA0026 (1)_1751590716691.jpg";
import ensembleImagePath from "@assets/IMG-20250704-WA0027 (1)_1751590716693.jpg";

const galleryItems = [
  {
    src: promoImagePath,
    alt: "Urfa Sıra Gecesi - Hayati İşler ve Ekibi Tanıtım"
  },
  {
    src: tvShowImagePath,
    alt: "TV Studio Programı - Geleneksel Performans"
  },
  {
    src: stagePerformancePath,
    alt: "Sahne Performansı - Solo Gösteri"
  },
  {
    src: traditionFestivalPath,
    alt: "Geleneksel Festivalde Performans"
  },
  {
    src: showPerformancePath,
    alt: "TV Show Performansı - Ekip ile Birlikte"
  },
  {
    src: ensembleImagePath,
    alt: "Geleneksel Sıra Gecesi - Ekip Performansı"
  }
];

export default function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  return (
    <section id="gallery" className="py-20 bg-cream">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="font-playfair font-bold text-4xl md:text-5xl text-turkish-red mb-4">
            Performans Galerisi
          </h2>
          <p className="text-lg text-warm-brown max-w-2xl mx-auto">
            Geçmiş etkinliklerimizden kareler ve unutulmaz anlar
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <motion.div
              key={index}
              className="group relative overflow-hidden rounded-xl shadow-lg cursor-pointer"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
              onClick={() => setSelectedImage(index)}
              whileHover={{ scale: 1.02 }}
            >
              <img
                src={item.src}
                alt={item.alt}
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-turkish-red/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <motion.i
                  className="fas fa-play text-gold-light text-3xl"
                  whileHover={{ scale: 1.2 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Modal for enlarged image */}
        {selectedImage !== null && (
          <motion.div
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
          >
            <motion.img
              src={galleryItems[selectedImage].src}
              alt={galleryItems[selectedImage].alt}
              className="max-w-full max-h-full object-contain rounded-lg"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
            />
            <button
              className="absolute top-4 right-4 text-white text-2xl"
              onClick={() => setSelectedImage(null)}
            >
              <i className="fas fa-times"></i>
            </button>
          </motion.div>
        )}
      </div>
    </section>
  );
}
