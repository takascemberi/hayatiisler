import { motion } from "framer-motion";

export default function Footer() {
  const services = [
    "Düğün Organizasyonları",
    "Konser & Sahne Performansları",
    "Geleneksel Sıra Geceleri",
    "Özel Etkinlikler",
    "Uluslararası Organizasyonlar"
  ];

  return (
    <footer className="bg-warm-brown text-cream py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-playfair font-bold text-2xl text-gold-light mb-4">
              <i className="fas fa-music mr-2"></i>
              Hayati İşler
            </h3>
            <p className="text-cream/80 leading-relaxed">
              20 yıllık tecrübemizle geleneksel Türk müziği ve sıra geceleri konusunda 
              profesyonel hizmet sunuyoruz.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-lg text-gold-light mb-4">Hizmetlerimiz</h4>
            <ul className="space-y-2 text-cream/80">
              {services.map((service, index) => (
                <li key={index}>• {service}</li>
              ))}
            </ul>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-lg text-gold-light mb-4">İletişim</h4>
            <div className="space-y-2 text-cream/80">
              <p><i className="fas fa-phone mr-2"></i> +90 537 383 93 45</p>
              <p><i className="fas fa-envelope mr-2"></i> hayatiisler35@gmail.com</p>
              <p><i className="fas fa-globe mr-2"></i> Tüm Türkiye ve dünyaya hizmet</p>
            </div>
          </motion.div>
        </div>
        
        <motion.div
          className="border-t border-cream/20 pt-8 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <p className="text-cream/60">
            © 2024 Hayati İşler - Urfa Sıra Gecesi. Tüm hakları saklıdır.
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
