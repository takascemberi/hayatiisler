import { motion } from "framer-motion";

export default function AboutSection() {
  const stats = [
    { number: "500+", label: "Başarılı Etkinlik" },
    { number: "20", label: "Yıl Tecrübe" },
    { number: "15", label: "Ülkede Performans" },
    { number: "100%", label: "Müşteri Memnuniyeti" }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-r from-turkish-red to-turkish-accent about-gradient-bg">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            className="text-black -mt-20 bg-white/90 p-8 rounded-xl"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="font-playfair font-bold text-4xl md:text-5xl mb-6 text-turkish-red">
              20 Yıllık Tecrübe
            </h2>
            <p className="text-lg leading-relaxed mb-6">
              Geleneksel Türk müziği ve özellikle Urfa sıra geceleri konusunda 
              20 yıllık deneyimimizle, her etkinliğinizde sizlere en kaliteli 
              müzik deneyimini sunuyoruz.
            </p>
            <p className="text-lg leading-relaxed mb-6">
              Kültürümüzün zenginliklerini müzikle buluşturarak, 
              geçmişten günümüze taşınan değerlerimizi yaşatmayı misyon edinmiş 
              bir ekip olarak hizmet veriyoruz.
            </p>

            {/* Promotional Text Cards */}
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              <motion.div
                className="p-4 rounded-lg bg-white/95 text-center shadow-lg"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <i className="fas fa-trophy text-turkish-red text-2xl mb-2"></i>
                <p className="text-sm font-semibold text-black">
                  "Türkiye'nin En Prestijli Sahnelerinde Performans"
                </p>
              </motion.div>
              
              <motion.div
                className="p-4 rounded-lg bg-white/95 text-center shadow-lg"
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
              >
                <i className="fas fa-heart text-turkish-red text-2xl mb-2"></i>
                <p className="text-sm font-semibold text-black">
                  "Binlerce Ailenin Mutluluk Anlarında Yanlarında"
                </p>
              </motion.div>
              
              <motion.div
                className="p-4 rounded-lg bg-white/95 text-center shadow-lg"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <i className="fas fa-globe-americas text-turkish-red text-2xl mb-2"></i>
                <p className="text-sm font-semibold text-black">
                  "Dünya Çapında Türk Kültürünün Elçisi"
                </p>
              </motion.div>
              
              <motion.div
                className="p-4 rounded-lg bg-white/95 text-center shadow-lg"
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                viewport={{ once: true }}
              >
                <i className="fas fa-star text-turkish-red text-2xl mb-2"></i>
                <p className="text-sm font-semibold text-black">
                  "Unutulmaz Anıların Mimarı"
                </p>
              </motion.div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  className="text-center p-6 bg-white/95 rounded-lg shadow-xl"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                >
                  <div className="text-3xl font-bold text-turkish-red mb-2">{stat.number}</div>
                  <div className="text-sm text-black">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img
              src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Traditional Turkish musicians performing"
              className="rounded-xl shadow-2xl w-full h-auto"
            />
            <motion.div
              className="absolute -bottom-6 -right-6 w-24 h-24 bg-gold-light rounded-full flex items-center justify-center shadow-lg"
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <i className="fas fa-award text-turkish-red text-3xl"></i>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
